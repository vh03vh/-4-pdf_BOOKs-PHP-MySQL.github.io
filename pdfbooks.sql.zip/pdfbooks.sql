-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2022 at 02:34 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `pdfbooks`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminName` varchar(50) character set latin1 NOT NULL default '',
  `adminEmail` varchar(50) character set latin1 NOT NULL default '',
  `adminPass` varchar(50) character set latin1 NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=cp1256;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminName`, `adminEmail`, `adminPass`) VALUES
('safaa', 'safa@gmail.com', 'safaa');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(20) NOT NULL auto_increment,
  `bookTitle` varchar(100) character set utf8 NOT NULL,
  `bookAuthor` varchar(100) character set utf8 NOT NULL,
  `bookCat` varchar(200) character set utf8 NOT NULL,
  `bookCover` varchar(200) character set utf8 NOT NULL,
  `book` varchar(100) character set utf8 NOT NULL,
  `bookContent` varchar(20000) character set utf8 NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1256 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `bookTitle`, `bookAuthor`, `bookCat`, `bookCover`, `book`, `bookContent`) VALUES
(41, ' Analyse MI', 'Allal Sadaoui', 'cours', '570_images (1).jpg', '315_Analyse MI.pdf', ' Analyse MI'),
(42, 'Proba et stat', 'Proba et stat', 'cours', '281_Capture.JPG', '582_Cours Proba.pdf', 'Proba et stat'),
(44, 'Questions modele OSI â€“TCP/IP', 'reseaux informatique', 'cours', '181_images (2).jpg', '563_Corrige TD3.pdf', ' reseaux informatique ..exrecices  cor '),
(45, 'Cours jQuery', 'Up Web', 'cours', '41_jquery.JPG', '714_cours jQuery.pdf', 'jQuery est une bibliothÃ¨queÂ JavaScriptÂ qui a pour but de soulager le dÃ©veloppeur des tÃ¢ches fastidieuses de gestion de compatibilitÃ© inter-navigateurs, ainsi que de lui fournir des effets classiques Â«Â clef en mainÂ Â».........\r\n'),
(46, 'Technologies webchapitre III : Le langage JavaScript', 'Mme Amani JARRAYA Mohamed MOHSEN', 'cours', '249_Capture2.JPG', '274_Technologies-web-chapitre-3--JavaScript-.pdf', 'Technologies webchapitre III : Le langage JavaScript'),
(47, 'Technologies webchapitre IV : Le langage PHP', 'Mme Amani JARRAYA   Mohamed MOHSEN', 'cours', '816_Capture3.JPG', '695_Technologies-web-chapitre-4--PHP-.pdf', 'PHP est un langage de script qui est principalement utilisÃ© pour Ãªtre exÃ©cutÃ© par un serveur Web.\r\n'),
(50, 'Programmation en langage C', 'Anne CANTEAUT', 'cours', '490_12.JPG', '587_cours.pdf', 'Programmation en langage C'),
(52, 'Les reseaux .', 'Reseaux doc', 'cours', '68_14.JPG', '955_cours.pdf', 'Les rÃ©seaux ont Ã©tÃ© et sont toujours dÃ©veloppÃ©s pour un certain nombre de raisons. Il y en a en fait\r\n4 principales.'),
(53, 'Reseaux Informatique', 'Karim Sehaba', 'cours', '417_16.JPG', '427_Reseaux.pdf', 'Reseaux Informatique'),
(10, 'JAVASCRIPT - COURS', 'Ivan KURZWEG', 'javascript livre', '217_javascript-cours.JPG', '36_gratuit.com--CoursJavaScript-id1783.pdf', 'Le langage Javascript\r\nCe langage, initialement crÃ©Ã© par la sociÃ©tÃ© Netscape, permet de rendre une page HTML bien plus interactive,\r\nen y insÃ©rant du code rÃ©agissant, par exemple, aux Ã©vÃ¨nements de lâ€™utilisateur, ou encore Ã \r\nvalider les donnÃ©es saisies dans un formulaire HTML. Dans ce premier chapitre, nous allons nous intÃ©resser\r\nÃ  la syntaxe du langage, mais aussi Ã  son organisation, en relation avec ce que vous avez vu en\r\ncours dâ€™algorithmique. Nous verrons ensuite les diffÃ©rents objets du navigateurs, et les maniÃ¨res de les\r\nprogrammer.'),
(11, 'PHP', 'Cours IUP â€“ PI2D Internet et MultimÃ©dias AnnÃ©e 20032004', 'php livre', '653_PHP.JPG', '88_cours-gratuit.com--CoursPhp-id990.pdf', '\r\nPHP\r\n(Hypertext Pre-Proc essor)\r\nQu''est ce que PHP ?\r\nUn langage de scripts gÃ©nÃ©raliste (perl ?)\r\nPour nous : un langage interprÃ©tÃ© par Apache pour gÃ©nÃ©rer\r\nune page HTML standard qui est transmise au client.\r\nIl s''agit alors de script exÃ©cutÃ© Â« cotÃ© serveur Â».\r\nPour nous : php4\r\nSimilaire : ASP (Active Server Pages), de chez Microsoft.\r\nSyntaxe proche language C.'),
(13, 'Cours-xsl/xslt', 'Luc Brun', 'ÙƒØªØ¨ Ø¹Ù„Ù…ÙŠØ©', '76_Creation de pages Web avec.JPG', '31_cours-gratuit.com--Coursxslxslt-id2020.pdf', 'XML : eXtensible Markup Language\r\n: Langage extensible de structuration de\r\ndonnÃ©es.\r\nXSL : eXtensible Stylesheet Language\r\n: Langage de transformation.\r\nAvantages :\r\n..\r\nStandard libre du W3C (www.w3c.org)\r\n..\r\nPrise en compte de nombreuses langues.\r\n..\r\nStockage de donnÃ©es au format texte\r\n\r\nFlexibilitÃ©.'),
(14, '1 DTD Document Type Definition/xml', 'DTD - Y. Bekkers - IFSIC', 'programmation', '650_DTD.JPG', '790_DTD-XML.pdf', ' DTD Document Type Definition/xml\r\nUn schÃ©ma de donnÃ©es\r\n=\r\nun dialecte\r\nâ€¢ Un schÃ©ma spÃ©cifie un dialecte XML\r\nâ€¢ Pour les applications : une grammaire\r\nÃ© ifi l f itÃ© d'' d t bi\r\nDTD - Y. Bekkers - IFSIC 4\r\nâ€“ vÃ©rifier la conformitÃ© d''un document bien\r\nformÃ© vis Ã  vis du dialecte considÃ©rÃ©\r\nâ€¢ Pour les utilisateurs : une spÃ©cification\r\nâ€“ spÃ©cifier, documenter, s''Ã©changer un dialecte'),
(32, 'Processus', 'ahmed benmoussa', 'cours', '570_3.JPG', '512_Processus.pdf', 'Processus'),
(31, 'Concepts fondamentaux des SE', 'ahmed benmoussa', 'cours', '883_2.JPG', '800_Concepts fondamentaux des SE.pdf', 'Concepts fondamentaux des SE'),
(33, 'Ordonnancement des Processus', 'ahmed benmoussa', 'cours', '768_4.JPG', '881_Ordonnancement des Processus.pdf', 'Ordonnancement des Processus'),
(34, 'Exclusion mutuelle', 'ahmed benmoussa', 'cours', '560_5.JPG', '772_Exclusion mutuelle.pdf', 'Exclusion mutuelle'),
(35, 'Les Moniteurs et autres mecanismes', 'ahmed benmoussa', 'cours', '344_6.JPG', '1_Les Moniteurs et autres mecanismes.pdf', 'Les Moniteurs et autres mecanismes'),
(36, 'Interblocage', 'ahmed benmoussa', 'cours', '46_7.JPG', '810_Interblocage.pdf', 'Interblocage des processus'),
(26, 'Systemes d exploitation Exercices gestion des processus', 'Systemes d exploitation', 'cours', '341_sysex.JPG', '639_Systemes d exploitation Exercices.pdf', 'Systemes d exploitation Exercices gestion des processus'),
(18, '1 Cours Outils de programmation pour les mathÃ©matiques', 'Mme Fatiha Charef', 'programmation', '809_matlab.JPG', '415_matlabcours.pdf', 'MATlabÂ« MATrix LABoratory Â»est un langage de haut niveau pour la programmation scientifique basÃ© sur le calcul matriciel (les variables manipulÃ©es sont des matrices), il est dÃ©veloppÃ© depuis 1984 par The MathWorks Company (http://www.mathworks.com/).Son noyau est composÃ© de librairies Ã©crites au dÃ©but en Fortran puis en C++.\r\nLâ€™objectif de MATLAB est de fournir aux chercheurs et ingÃ©nieurs un environnement de calcul numÃ©rique Ã  la fois simple Ã  utiliser et efficace.\r\nMATLAB permet le travail interactif soit en mode commande (interactif), soit en mode programmation (exÃ©cutif).'),
(23, 'Flex&Bison', 'Fabrice Harrouet', 'cours', '613_flex.JPG', '999_Flex_Bison.pdf', 'Generer un analyseur avec Flex&Bison');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL auto_increment,
  `categoryName` varchar(200) character set utf8 NOT NULL,
  `categoryDate` date NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1256 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categoryName`, `categoryDate`) VALUES
(6, 'javascript livre', '0000-00-00'),
(7, 'php livre', '0000-00-00'),
(8, 'ÙƒØªØ¨ Ø¹Ù„Ù…ÙŠØ©', '0000-00-00'),
(17, 'programmation', '0000-00-00'),
(18, 'cours', '0000-00-00'),
(19, 'cours', '0000-00-00'),
(20, 'cours sys ex', '0000-00-00');
